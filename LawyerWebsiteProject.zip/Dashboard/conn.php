<?php

$conn = mysqli_connect('localhost','root','','ecommerce') or die('connection failed');

?>